<style>
img{
    background-position:cover;
    width:1270px;
    margin-top:-22px;
}

</style>
<div class="" stye="padding:0;margin:0;">
    <img src="<?= base_url('assets/team.jpg');?>" alt="Team Work" style="background-position:cover;">
</div>